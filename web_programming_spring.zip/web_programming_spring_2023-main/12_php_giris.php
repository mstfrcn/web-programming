<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        #t{
            font-size: 20px;
            border-radius: 3px;
            border : 3px solid red;
        }
    </style>
</head>
<body>

<?php
echo "<h2> PHP'ye hoşgeldiniz! </h2>";
echo "<input type='text' id='t'>";
?>

</body>
</html>