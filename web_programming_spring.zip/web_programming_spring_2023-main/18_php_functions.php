<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fonksiyonlar</title>
</head>
<body>
<?php
// function baglan($degisken1, $değisken2){
// return $degisken
// }

function topla($a , $b){
    return $a + $b;
}

$a = 5;
$b = 8;
echo topla($a,$b);


?>

</body>
</html>