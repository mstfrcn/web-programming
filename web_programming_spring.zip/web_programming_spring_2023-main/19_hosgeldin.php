<?php
    $isim = $_POST["isim"];
    echo "Hoşgeldin ".$isim;
?>