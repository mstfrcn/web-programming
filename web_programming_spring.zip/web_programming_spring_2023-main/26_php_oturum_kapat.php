<?php
session_unset();
session_abort();
echo "Oturum kapatıldı<br><br>";
echo "<a href='26_php_kullanici_form.html'>Yeniden Giriş Yap</a>"
?>
