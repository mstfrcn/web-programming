# web_programming_spring_2023
web_programming_spring_2023

Bu derste web programcılığının temelleri, web otomasyonlarının nasıl geliştirildiği ve tasarım ilkelerinden bahsedilecektir.

Derste haftalık ödevler ve proje verilecektir.<br> 
Haftalık ödevler verildiği hafta yapılmalıdır. Teslim Tarihi geçen ödevin telafisi olmayacaktır.<br>
Projeler Final haftasından önceki hafta ders saatinde kontrol edilecektir.(Dersi alttan alanlar sınav haftasında laptopları ile gelip göstereceklerdir.) Proje teslim etmeyen öğrenciler dersten kalırlar. Proje teslimini büte bırakan öğrenciler büt haftasında sınavdan sonra laptopları ile projelerini göstereceklerdir. Tüm öğrencilerin ilk 4 hafta içerisinde projelerini belirlemesi gerekmektedir.<br>
Devamsızlık hakkı 4 haftadır. (Devamsızlıklar her hafta düzenli olarak OBS sistemine işleneceğinden geriye dönük hiç bir mazeret kabul edilmeyecektir.)<br>

Kodlama için herhangi bir IDE kullanılabilir. Derste PHPStorm, WebStorm ve VSCode kullanacağız.<br>
Php için Wamp Server programının kurulması gerecektir.<br>
NodeJs işlemleri ise ilgili hafta geldiğinde açıklanacaktır.<br>

Vize : 100 puanlık test sınavı<br>
Final (Bütünleme) : 25 Puanlık sınav + 25 puan haftalık ödevler + 50 puan proje

--- Müfredat Ana Başlıklar ---<br>
-Temel Web Tasarım<br>
-PHP çalışma ortamının hazırlanması<br>
-PHP ile temel programlama<br> 
-PHP ile veritabanı işlemleri<br>
-PHP+Mysql+Bootstrap ile web uygulamaları<br>
-Laravel ve CodeIgniter MVC temel bilgiler<br>
-NodeJs kurulum<br>
-Nodejs temel bilgiler, paketler<br>
-Nodejs + NoSql veritabanı bağlantısı<br>
-Frontend için JS frameworkleri (react, vue, angular vb.)<br>
*** Müfredat öğrencinin hazırbulunuşluğuna, reaksiyonuna ve ritmine göre değişebilir<br>
